package cs.tcd.ie;
/*
 * client class 
 * they are basically end points of the network or users. 
 * This design implements a network of 4 end users
 * @Author: Leong Kai Ler
 */
import java.net.DatagramSocket;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.util.HashMap;

import tcdIO.*;

public class Client extends Node{
	static final String DEFAULT_DST_NODE = "localhost";	
	Terminal terminal;
	InetSocketAddress firstAddress,dstAddress;
	int srcPort;
	int []dstPort;
	boolean done=false;
	String dstHost;

	Client (Terminal terminal, String dstHost, int dstPort1, int dstPort2, int dstPort3, int srcPort, int firstPort)
	{
		try {
			this.terminal=terminal;
			this.dstHost=dstHost;
			this.dstPort = new int [3];
			dstPort [0]= dstPort1;
			dstPort [1]= dstPort2;
			dstPort [2]= dstPort3;
			this.srcPort=srcPort;
			this.socket = new DatagramSocket(this.srcPort);
			this.firstAddress=new InetSocketAddress (this.dstHost,firstPort);
			listener.go();
		} catch (SocketException e) {e.printStackTrace();}
	}

	@Override
	public void onReceipt(DatagramPacket packet) throws Exception {
		terminal.println("\nReceived");
	}

	public void start () throws Exception
	{
		DatagramPacket packet= null;
		String message;
		int targetUser;
		while(!done)
		{
			message=terminal.readString("String to send: ");
			//if done then just quit 
			if (message.isEmpty()||message.equalsIgnoreCase("done"))
			{
				this.done=true;
				terminal.println("goodbye");
				socket.close();
			}
			else{
				terminal.println(message);
				/*check which user to send to 
				 * Each user has 3 endpoints to communicate with, provided that all of them are available
				 */
				targetUser=Integer.parseInt(terminal.readString("which user to send to:"));
				if (targetUser<1||targetUser>3)
				{
					targetUser=2;
				}
				terminal.println("Sending packet to user"+targetUser+"...");
				packet=new StringContent(message).toDatagramPacket(srcPort, dstPort[targetUser-1], delimiter);
				packet.setSocketAddress(firstAddress);
				socket.send(packet);
			}			
		}
	}

	/*
	 * start each client individually
	 * email me if anything goes wrong
	 */
	public static void main(String[] args) {
		try {
			Terminal terminal0= new Terminal("Client0");		
			Client client0 = new Client(terminal0, DEFAULT_DST_NODE, 40001,40002,40003,40000,40004);
			client0.start();
			Terminal terminal1=new Terminal("Client1");
			Client client1 = new Client(terminal1, DEFAULT_DST_NODE, 40000,40002,40003,40001,40005);
			client1.start();
			Terminal terminal2=new Terminal("Client2");
			Client client2 = new Client(terminal2, DEFAULT_DST_NODE, 40000,40001,40003,40002,40006);
			client2.start();
			Terminal terminal3=new Terminal("Client3");
			Client client3 = new Client(terminal3, DEFAULT_DST_NODE, 40000,40001,40002,40003,40007);
			client3.start();				
		} catch(java.lang.Exception e) {e.printStackTrace();}
	}
}