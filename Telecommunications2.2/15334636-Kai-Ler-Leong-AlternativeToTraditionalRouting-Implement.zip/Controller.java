package cs.tcd.ie;
/*
 * controller class
 * this class constructs a path table using the Dijkstra algorithm by Robert Sedgewick and Kevin Wayne from Princeton.
 * I have 4 points of end user in the network
 * As the distance between each nodes varies, to figure out which path is the shortest, Dijkstra algorithim is 
 * efficient in doing this. This is because it can form up a map of shortest possible paths from a point. Or in this context,
 * I just need to find the shortest paths from one end user to the other three, and thus, ths same for the other 3.
 * MyKey is used to store the paths for each sets of source and destination node
 * @Author: Leong Kai Ler
 */
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.util.ArrayList;

import tcdIO.Terminal;

public class Controller extends Node{

	static final String DEFAULT_DST_NODE = "localhost";
	String dstHost;
	Terminal terminal;
	MyKey [] keys;

	Controller (Terminal terminal, String dstHost)
	{
		try {
			this.terminal=terminal;
			this.dstHost=dstHost;
			socket=new DatagramSocket(CONTROLLER_PORT);
			keys= new MyKey[12];
			connect();
			listener.go();
		} catch (SocketException e) {e.printStackTrace();}
	}

	@Override
	public void onReceipt(DatagramPacket packet) throws Exception {	
		StringContent content = new StringContent(packet);
		int srcPort=content.getsrcPort();
		int dstPort=content.getdstPort();
		terminal.println("received request from "+srcPort+" to "+dstPort);
		int [] path=check(srcPort,dstPort);
		//reply
		sendpacket(srcPort,dstPort,path);
	}

	private int[] check(int srcPort,int dstPort)
	{	
		int list[] = null;
		for (int i=0; i<this.keys.length; i++)
		{
			if (keys[i].containz(srcPort-40000, dstPort-40000))
			{
				list=keys[i].getPath();
			}
		}
		return list;
	}

	private void sendpacket (int srcPort, int dstPort, int [] path) throws Exception
	{
		String reply;
		for (int i=1; i<path.length-1; i++){
			reply =""+path[i+1];
			DatagramPacket response = new StringContent(reply).toDatagramPacket(srcPort,dstPort,delimiter);
			InetSocketAddress node = new InetSocketAddress(dstHost,path[i]+40000);
			response.setSocketAddress(node);
			terminal.println("sending to...."+response.getPort());
			socket.send(response);
		}
	}

	/*
	 * Construct the path table 
	 * return integer array of nodes to be passed.
	 * the array has to be reversed since the path form by Dijkstra is the other way around.
	 * store the path in MyKey array. 
	 * In the text file, EWD.txt first line consists of the number of routers as vertices and
	 * second number is the number of connections as edges 
	 * then it lists out all the connections of nodes and their weighted distances
	 */
	public void connect()
	{
		In in = new In("EWD.txt");
		EdgeWeightedDigraph G = new EdgeWeightedDigraph(in);
		int [][] pointTopoint = {{1,2,3},{0,2,3},{0,1,3},{0,1,2}};
		int k=0;
		for (int i=0; i<pointTopoint.length; i++)
		{
			for (int j=0; j<pointTopoint[i].length;j++)
			{
				int [] list = construct(i,pointTopoint[i][j],G);
				keys[k]=new MyKey (i,pointTopoint[i][j],list);
				k++;
			}
		}
	}

	public int [] construct(int src, int dst, EdgeWeightedDigraph G)
	{
		ArrayList <Integer> temp = new ArrayList <Integer>();
		DijkstraSP sp = new DijkstraSP(G, src);
		if (sp.hasPathTo(dst))
		{
			for (DirectedEdge e : sp.pathTo(dst)) {
				temp.add(e.to());
			}
		}
		int [] list = reverse(temp,src);
		return list;
	}

	private int [] reverse(ArrayList <Integer> y,int src)
	{
		int [] list= new int [y.size()+1];
		int j=1;
		list[0]=src;
		for (int i=y.size()-1; i>=0; i--)
		{
			list[j]=y.get(i).intValue();
			j++;		
		}
		return list;
	}

	public synchronized void start()
	{
		try {
			terminal.println("Waiting for contact");
			this.wait();
		} catch(java.lang.Exception e) {e.printStackTrace();}
	}

	public static void main(String[] args) {
		try {					
			Terminal terminal= new Terminal("Controller");		
			(new Controller(terminal, DEFAULT_DST_NODE)).start();
		} catch(java.lang.Exception e) {e.printStackTrace();}
	}
}
