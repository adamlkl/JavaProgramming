package cs.tcd.ie;

/*
 * Each node of a router has a unique node number and destination address of the other node it is bind to.
 * @Author: Leong Kai Ler
 */
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import tcdIO.Terminal;

public class RouterNodes {

	Terminal terminal;
	int node;
	InetSocketAddress dstAddress;

	public RouterNodes(int node, Terminal terminal)
	{	
		this.node = node;
		this.terminal=terminal;	
	}
	
	//check which node to send to 
	public int getNode(){
		return this.node;
	}

	public void connect (String dstHost, int dstPort)
	{
		terminal.println("node"+this.node+"connected");
		this.dstAddress=new InetSocketAddress(dstHost,dstPort);
	}

	public void sendPacket (DatagramPacket packet, DatagramSocket socket) throws Exception{
		if (this.dstAddress!=null){
			terminal.println("send from "+ socket.getLocalPort()+"to"+this.dstAddress.getPort());
			packet.setSocketAddress(this.dstAddress);
			socket.send(packet);
		}
	}
}
