package cs.tcd.ie;

import java.net.DatagramPacket;

/*
 *This class represents a set of values.
 *I created this class to store the values of each unique set if point-to-point combination of end users
 *I was initially using hash map instead of this, but I get a problem where the end users might be the same, 
 *which means the source and destination are the same at some point. This prevents me from having 12 sets of 
 *values with a combination 2 keys. So I created this class to solve my problem. x represents the srcPort and y 
 *as the dstPort. z will represent the path of nodes.
 *
 *Author: Leong Kai Ler
 */
public class MyKey {
	int x,y;
	int [] path;

	public MyKey(int x, int y, int[] z)
	{
		this.x=x;
		this.y=y;
		this.path=z;
	}
	
	public boolean containz(int x, int y)
	{
		if (this.x==x && this.y==y)return true;
		else return false;
	}
	
	public int getx()
	{
		return x;
	}

	public int gety()
	{
		return y;
	}
	
	public int[] getPath()
	{
		return path;
	}
	
	public String toString()
	{
		return new String(x+","+y);
	}
}
